<?php
/**
 * PHP 7 prototypes
 */

if (!function_exists('random_bytes')) {
    function random_bytes($length) {}
}

if (!function_exists('random_int')) {
    function random_int($min, $max) {}
}
