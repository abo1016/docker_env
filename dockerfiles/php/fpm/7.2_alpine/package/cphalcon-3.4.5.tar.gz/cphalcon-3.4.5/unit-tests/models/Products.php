<?php

class Products extends \Phalcon\Mvc\Model
{

}
