<?php

/**
 * Personas
 *
 * Personas is people in spanish
 */
class Personas extends Phalcon\Mvc\Model
{

}
