<?php

class M2MRobotsParts extends Phalcon\Mvc\Model
{
	public function getSource()
	{
		return 'm2m_robots_parts';
	}
}
