function popdown() {
    alert("Goodbye World");
}