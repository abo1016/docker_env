<?php

namespace Phalcon\Test\Models;

class Products extends \Phalcon\Mvc\Model
{
}
