<?php

namespace Phalcon\Test\Collections\Bookshelf;

use Phalcon\Mvc\Collection;

/**
 * Books Collection
 *
 * @property string title
 *
 * @package Phalcon\Test\Collections
 */
class Magazines extends Collection
{
}
