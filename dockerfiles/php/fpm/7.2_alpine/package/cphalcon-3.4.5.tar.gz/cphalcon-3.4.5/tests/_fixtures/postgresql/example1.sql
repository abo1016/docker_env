CREATE TABLE "table" (
	"column1" CHARACTER VARYING(10) NULL,
	"column2" INT NULL
);
