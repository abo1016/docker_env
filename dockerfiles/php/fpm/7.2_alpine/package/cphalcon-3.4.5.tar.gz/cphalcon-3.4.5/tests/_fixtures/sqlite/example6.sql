CREATE TABLE "table" (
	`column14` TINYBLOB NOT NULL,
	`column16` BLOB NOT NULL
)
