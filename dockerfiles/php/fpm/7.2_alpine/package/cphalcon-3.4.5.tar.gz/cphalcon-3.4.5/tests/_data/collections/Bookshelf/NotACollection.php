<?php

namespace Phalcon\Test\Collections\Bookshelf;

class NotACollection
{
}
