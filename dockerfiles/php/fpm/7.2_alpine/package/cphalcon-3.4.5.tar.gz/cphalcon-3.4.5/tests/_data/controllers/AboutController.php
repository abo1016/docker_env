<?php

class AboutController
{
    /**
     * @Get("/about/team")
     */
    public function teamAction()
    {
    }

    /**
     * @Post("/about/team")
     */
    public function teamPostAction()
    {
    }
}
