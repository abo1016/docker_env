CREATE TABLE "table" (
	`column9` VARCHAR(10) DEFAULT "column9",
	`column10` INTEGER DEFAULT "10"
)
