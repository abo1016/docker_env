<?php

class MainController
{
    /**
     * @Get("/")
     */
    public function indexAction()
    {
    }
}
