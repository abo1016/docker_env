CREATE TABLE `table` (
	`column1` VARCHAR(10) NULL,
	`column2` INT(18) UNSIGNED NULL
)
