<?php

namespace Phalcon\Test\Modules\Frontend\Controllers;

use Phalcon\Mvc\Controller;

class IndexController extends Controller
{
    public function indexAction()
    {
    }
}
