---
name: BUG提交模版
about: Create a report to help us improve

---

**一定要读**
在提交BUG之前请查阅README文件，常见的安装与配置问题都有对应解决办法 。再查看历史ISSUE https://github.com/laynefyc/xhgui-branch/issues?utf8=%E2%9C%93&q=is%3Aissue 是否有答案。都解决不了，请认真填写如下信息

**版本信息:**
 - 操作系统: [e.g. CentOS 6.8]
 - PHP [e.g. PHP7.1.13]
 - 扩展 [e.g. tideway.so v1.1.14]
 - MongodDB 版本 [e.g. MongodDB v4.0.4]

**PHP信息:**
1. 运行php -m 将结果粘贴到当前文本中
2. 重启php-fpm 问题是否还在？
3. 直接在浏览器中访问 http://test.com/xhgui-branch/external/header.php  （修改为自己的URL）是否报错

**具体报错信息：**


