<?php

interface Xhgui_Saver_Interface
{
    public function save($data);
}
