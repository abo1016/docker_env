<?php

echo "Hello Auto Prepend!";
